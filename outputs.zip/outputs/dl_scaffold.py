def dl_scaffold():
    print("Run this in a GPU Colab runtime")
